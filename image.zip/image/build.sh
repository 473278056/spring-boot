# edit images list
IMAGE_ARRAY=(10.249.131.249:30002/library/staffai/notebook:tf1.13.1-cpu-py3.6-fairing0.7.1.21 \
			10.249.131.249:30002/library/staffai/notebook:tf1.13.1-gpu-py3.6-fairing0.7.1.21 \
			10.249.131.249:30002/library/staffai/notebook:tf2.0.0-cpu-py3.6-fairing0.7.1.21 \
			10.249.131.249:30002/library/staffai/notebook:tf2.0.0-gpu-py3.6-fairing0.7.1.21)

for BASE_IMAGE in ${IMAGE_ARRAY[@]}
do
    TARGET_IMAGE=${BASE_IMAGE}
    echo $TARGET_IMAGE
    docker build -f Dockerfile -t $TARGET_IMAGE --build-arg BASE_IMAGE="$BASE_IMAGE" .
    docker push $TARGET_IMAGE
done
